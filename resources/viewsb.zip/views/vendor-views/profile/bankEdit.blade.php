@extends('layouts.vendor.app')

@section('title',translate('messages.bank_info'))



@section('content')

@endsection
