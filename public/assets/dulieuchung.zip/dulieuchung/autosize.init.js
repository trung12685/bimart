//====================STAR RATING INIT=================//
autosize(document.querySelectorAll('.textarea-autosize'));
//====================STAR RATING INIT=================//